import sys
from model.Vaccine import Vaccine
from model.Caregiver import Caregiver
from model.Patient import Patient
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql
import datetime
import random


'''
objects to keep track of the currently logged-in user
Note: it is always true that at most one of currentCaregiver and currentPatient is not null
        since only one user can be logged-in at a time
'''
current_patient = None

current_caregiver = None


def strong_password(password):
    # check password strength
    special_character = ['!', '@', "#", "?"]
    # 8 characters
    if len(str(password)) < 8:
        print('Please enter a strong password with at least 8 characters')
        print('A password must contain: at least 8 characters, upper and lowercase letters,')
        print(' both numbers and letters, and at least one special character' + str(special_character))
        return False
    # Mix of upper and lowercase
    upper_status = False
    lower_status = False
    for letter in str(password):
        if (upper_status is False) or (lower_status is False):
            if letter.isupper():
                upper_status = True
            if letter.islower():
                lower_status = True
    if not(upper_status and lower_status):
        print('Please enter a strong password with mixed case')
        print('A password must contain: at least 8 characters, upper and lowercase letters,')
        print(' both numbers and letters, and at least one special character' + str(special_character))
        return False
    # Mix of letters and numbers
    if not (str(password).isalpha()) and (str(password).isdigit()):
        print('Please enter a strong password with both numbers and letters')
        print('A password must contain: at least 8 characters, upper and lowercase letters,')
        print(' both numbers and letters, and at least one special character' + str(special_character))
        return False
    # A special character
    special = False
    if not special:
        for sp_c in special_character:
            if sp_c in str(password):
                special = True
    if not special:
        print('Please enter a strong password with at least one special character')
        print('A password must contain: at least 8 characters, upper and lowercase letters,')
        print(' both numbers and letters, and at least one special character' + str(special_character))
        return False
    if '69' in str(password):
        print('nice')
    return True


def create_patient(tokens):
    """
    TODO: Part 1
    """
    # create_patient <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please enter all/only require inputs")
        return

    username = tokens[1]
    password = tokens[2]

    # check strength of password
    if not strong_password(password):
        return

    # check 2: check if the username has been taken already
    if username_exists_patient(username) is True:
        print("Username taken, try again!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the patient
    try:
        patient = Patient(username, salt=salt, hash=hash)
        # save to patient information to our database
        patient.save_to_db()
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return


def create_caregiver(tokens):
    # create_caregiver <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please enter all/only require inputs")
        return

    username = tokens[1]
    password = tokens[2]

    # check password strength
    if not strong_password(password):
        return

    # check 2: check if the username has been taken already
    if username_exists_caregiver(username):
        print("Username taken, try again!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the caregiver
    try:
        caregiver = Caregiver(username, salt=salt, hash=hash)
        # save to caregiver information to our database
        caregiver.save_to_db()
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return


def username_exists_caregiver(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Caregivers WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        result = cursor.fetchall()
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        if len(result) != 0:
            return True
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False


def username_exists_patient(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Patients WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        result = cursor.fetchall()
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        if len(result) != 0:
            return True
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False


def login_caregiver(tokens):
    # login_caregiver <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_caregiver
    if current_caregiver is not None or current_patient is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please enter all/only require inputs")
        return

    username = tokens[1]
    password = tokens[2]

    caregiver = None
    try:
        caregiver = Caregiver(username, password=password).get()
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if caregiver is None:
        print("That caregiver username does not exist")
    else:
        print("Caregiver logged in as: " + username)
        current_caregiver = caregiver


def login_patient(tokens):
    """
    TODO: Part 1
    """
    # login_patient <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_patient
    if current_patient is not None or current_caregiver is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please enter all/only require inputs")
        return

    username = tokens[1]
    password = tokens[2]

    patient = None
    try:
        patient = Patient(username, password=password).get()
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if patient is None:
        print("That patient username does not exist")
    else:
        print("Patient logged in as: " + username)
        current_patient = patient


def search_caregiver_schedule(tokens):
    """
    TODO: Part 2
    """
    global current_caregiver
    global current_patient
    # check Login status
    if current_caregiver is None and current_patient is None:
        print("Please login first!")
        return

    # check token length
    if len(tokens) != 2:
        print("Please enter all/only require inputs")
        return

    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy
    date_tokens = date.split("-")
    if len(date) !=10:
        print('Please enter date in mm-dd-yyyy format')
        print('Please try again')
        return
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    d = datetime.datetime(year, month, day)

    if current_caregiver is None:
        if current_patient.get_availability(d) is not None:
            avail_caregivers, vaccines = current_patient.get_availability(d)
        else:
            return
    else:
        if current_caregiver.get_availability(d) is not None:
            avail_caregivers, vaccines = current_caregiver.get_availability(d)
        else:
            return

    print("The following caregivers are available for " + str(d) + ":")
    for cg in avail_caregivers:
        print(cg)
    print("The following vaccines are available:")
    for vac in vaccines:
        print(str(vac[1]) + " of " + str(vac[0]))


def reserve(tokens):
    """
    patients are randomly assigned a caregiver
    date, vaccine
    TODO: Part 2
    """
    global current_patient
    # check Login status
    if current_patient is None:
        print("Please login as a patient first!")
        return

    if len(tokens) != 3:
        print("Please enter all/only require inputs")
        return

    # check token for date
    date = tokens[1]
    if len(date) !=10:
        print('Please enter date in mm-dd-yyyy format')
        print('Please try again')
        return
    # assume input is hyphenated in the format mm-dd-yyyy
    date_tokens = date.split("-")
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    d = datetime.datetime(year, month, day)
    today = d.today()
    if (d - today).total_seconds() < -86400:
        print('You cannot make reservations for past days')
        print('Please try again')
        return

    # set vaccine_name
    vaccine_name = str(tokens[2])

    # make sure a caregiver is available
    if current_patient.get_availability(d) is None:
        return
    avail_caregivers, vaccines = current_patient.get_availability(d)
    res_caregiver = random.choice(avail_caregivers)
    current_patient.make_reservation(res_caregiver, vaccine_name, d)



def upload_availability(tokens):
    #  upload_availability <date>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    # check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
    if len(tokens) != 2:
        print("Please enter all/only require inputs")
        return

    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy
    date_tokens = date.split("-")
    if len(date) !=10:
        print('Please enter date in mm-dd-yyyy format')
        print('Please try again')
        return
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    d = datetime.datetime(year, month, day)

    today = d.today()
    if (d - today).total_seconds() < -86400:
        print('You cannot upload availabilities for past days')
        print('Please try again')
        return

    #check if they already have appt on day
    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)
    have_appointments = 'SELECT * FROM Schedule WHERE CID=%s'
    cursor.execute(have_appointments, current_caregiver.get_username())
    result = cursor.fetchall()
    for row in result:
        if str(row['Time']) == str(d)[0:10]:
            print('You are already scheduled for an appointment that day')
            return

    try:
        current_caregiver.upload_availability(d)
    except ValueError:
        print("Please enter a valid date!")
    except pymssql.Error as db_err:
        print("Error occurred when uploading availability")


def cancel(tokens):
    """
    TODO: Extra Credit
    """
    pass


def add_doses(tokens):
    #  add_doses <vaccine> <number>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    #  check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please enter all/only require inputs")
        return

    vaccine_name = str(tokens[1])
    doses = int(tokens[2])
    vaccine = None

    # check if valid vaccine
    if vaccine_name.capitalize() not in vaccineNames:
        print("Invalid vaccine name " + vaccine_name)
        print("Please try again with a vaccine from one of the following")
        error_message = ''
        for name in vaccineNames:
            error_message += str(name) + ' '
        print(error_message)
        return

    try:
        vaccine = Vaccine(vaccine_name, doses).get()
    except pymssql.Error:
        print("Error occurred when adding doses")

    # check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
    #          table

    if vaccine is None:
        try:
            vaccine = Vaccine(vaccine_name, doses)
            vaccine.save_to_db()
        except pymssql.Error:
            print("Error occurred when adding doses")
    else:
        # if the vaccine is not null, meaning that the vaccine already exists in our table
        try:
            vaccine.increase_available_doses(doses)
        except pymssql.Error:
            print("Error occurred when adding doses")

    print("Doses updated!")


def show_appointments(tokens):
    '''
    TODO: Part 2
    '''
    global current_caregiver
    global current_patient
    # check Login status
    if current_caregiver is None and current_patient is None:
        print("Please login first!")
        return

    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)

    if current_patient is not None:
        show_appointments = 'SELECT AppointmentID, Vaccine, Time, CID FROM Schedule WHERE PID=%s'
        cursor.execute(show_appointments, current_patient.get_username())
    else:
        show_appointments = 'SELECT AppointmentID, Vaccine, Time, PID FROM Schedule WHERE CID=%s'
        cursor.execute(show_appointments, current_caregiver.get_username())
    result = cursor.fetchall()
    if len(result) == 0:
        print('You have no scheduled appointments')
        return
    print('You have the following appointments:')
    for row in result:
        if current_patient is not None:
            print('AppointmentID: '+str(row['AppointmentID'])+' for '+str(row['Vaccine'])+' vaccination on '
                  + str(row['Time']) + ' with ' + str(row['CID']))
        else:
            print('AppointmentID: ' + str(row['AppointmentID']) + ' for ' + str(row['Vaccine']) + ' vaccination on '
                  + str(row['Time']) + ' with ' + str(row['PID']))
    return result

def logout(tokens):
    """
    TODO: Part 2
    """
    global current_patient
    global current_caregiver

    if current_patient is None and current_caregiver is None:
        print("Already logged-out!")
        return
    else:
        current_patient = None
        current_caregiver = None
        print("Successfully logged-out!")


def start():
    stop = False
    while not stop:
        print()
        print(" *** Please enter one of the following commands *** ")
        print("> create_patient <username> <password>")  # //TODO: implement create_patient (Part 1)
        print("> create_caregiver <username> <password>")
        print("> login_patient <username> <password>")  #// TODO: implement login_patient (Part 1)
        print("> login_caregiver <username> <password>")
        print("> search_caregiver_schedule <date>")  #// TODO: implement search_caregiver_schedule (Part 2)
        print("> reserve <date> <vaccine>") #// TODO: implement reserve (Part 2)
        print("> upload_availability <date>")
        print("> cancel <appointment_id>") #// TODO: implement cancel (extra credit)
        print("> add_doses <vaccine> <number>")
        print("> show_appointments")  #// TODO: implement show_appointments (Part 2)
        print("> logout") #// TODO: implement logout (Part 2)
        print("> Quit")
        print()
        response = ""
        print("> Enter: ", end='')

        try:
            response = str(input())
        except ValueError:
            print("Type in a valid argument")
            break
        tokens = response.split(" ")
        if len(tokens) == 0:
            ValueError("Try Again")
            continue
        operation = tokens[0]
        if (operation != "create_patient") and (operation != "create_caregiver"):
            response = response.lower()
        if operation == "create_patient":
            create_patient(tokens)
        elif operation == "create_caregiver":
            create_caregiver(tokens)
        elif operation == "login_patient":
            login_patient(tokens)
        elif operation == "login_caregiver":
            login_caregiver(tokens)
        elif operation == "search_caregiver_schedule":
            search_caregiver_schedule(tokens)
        elif operation == "reserve":
            reserve(tokens)
        elif operation == "upload_availability":
            upload_availability(tokens)
        elif operation == cancel:
            cancel(tokens)
        elif operation == "add_doses":
            add_doses(tokens)
        elif operation == "show_appointments":
            show_appointments(tokens)
        elif operation == "logout":
            logout(tokens)
        elif operation == "quit":
            print("Thank you for using the scheduler, Goodbye!")
            stop = True
        else:
            print("Invalid Argument")


if __name__ == "__main__":
    '''
    // pre-define the three types of authorized vaccines
    // note: it's a poor practice to hard-code these values, but we will do this ]
    // for the simplicity of this assignment
    // and then construct a map of vaccineName -> vaccineObject
    '''
    vaccineNames = ["Moderna", "Pfizer", "Johnson", "Astrazeneca"]
    # start command line
    print()
    print("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!")

    start()
