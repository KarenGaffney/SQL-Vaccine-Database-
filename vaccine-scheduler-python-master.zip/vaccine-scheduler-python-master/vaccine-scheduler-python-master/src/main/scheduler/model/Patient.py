import sys
sys.path.append("../util/*")
sys.path.append("../db/*")
from model.Vaccine import Vaccine
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql


class Patient:
    def __init__(self, username, password=None, salt=None, hash=None):
        self.username = username
        self.password = password
        self.salt = salt
        self.hash = hash

    # getters
    def get(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        get_patient_details = "SELECT Salt, Hash FROM Patients WHERE Username = %s"
        try:
            cursor.execute(get_patient_details, self.username)
            for row in cursor:
                curr_salt = row['Salt']
                curr_hash = row['Hash']
                calculated_hash = Util.generate_hash(self.password, curr_salt)
                if not curr_hash == calculated_hash:
                    cm.close_connection()
                    return None
                else:
                    self.salt = curr_salt
                    self.hash = calculated_hash
                    return self
        except pymssql.Error:
            print('Error occurred when getting Patients')
            cm.close_connection()

        cm.close_connection()
        return None

    def get_username(self):
        return self.username

    def get_salt(self):
        return self.salt

    def get_hash(self):
        return self.hash

    def save_to_db(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor()

        add_patients = "INSERT INTO Patients VALUES (%s, %s, %s)"
        try:
            cursor.execute(add_patients, (self.username, self.salt, self.hash))
            # you must call commit() to persist your data if you don't set autocommit to True
            conn.commit()
        except pymssql.Error as db_err:
            print("Error occurred when inserting Patients")
            sqlrc = str(db_err.args[0])
            print("Exception code: " + str(sqlrc))
            cm.close_connection()
        cm.close_connection()

    def get_availability(self, d):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor()

        get_availability = "SELECT Username FROM Availabilities WHERE Time=%s"
        try:
            cursor.execute(get_availability, d)
            if cursor.rowcount == 0:
                print("Sorry, there are no caregivers available on " + str(d) + ":")
                print("Please try again")
                return None
            # print("The following caregivers are available for " + str(d) + ":")
            avail_caregivers = []
            for row in cursor:
                avail_caregivers.append(row[0])
                # print(row[0])
        except ValueError:
            print("Please enter a valid date!")
        except pymssql.Error as db_err:
            print("Error occurred when searching caregiver schedule")

        # vaccine availability
        get_vaccine = "SELECT Name, Doses FROM Vaccines"
        try:
            cursor.execute(get_vaccine)
            # print("The following vaccines are available:")
            vaccines = []
            if cursor.rowcount == 0:
                print("The following caregivers are available for " + str(d) + ":")
                for cg in avail_caregivers:
                    print(cg)
                print("Sorry, there are no vaccines available")
                return None
            for row in cursor:
                v_name = row[0]
                dose_n = row[1]
                vaccines.append((v_name, dose_n))
                # print(str(dose_n)+" of "+str(v_name))

        except pymssql.Error:
            print("Error occurred when getting Vaccine")
            cm.close_connection()
        cm.close_connection()

        return avail_caregivers, vaccines


    def make_reservation(self, res_caregiver, vaccine_name, d):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor()

        # make sure valid vaccine
        vaccineNames = ["Moderna", "Pfizer", "Johnson", "Astrazeneca"]
        if vaccine_name.capitalize() not in vaccineNames:
            print("Please enter a vaccine from this list")
            print(vaccineNames)
            return

        # make sure vaccine is available
        get_vaccine = "SELECT Doses FROM Vaccines WHERE Name=%s"
        try:
            cursor.execute(get_vaccine, vaccine_name)
            # print("The following vaccines are available:")
            for row in cursor:
                if row[0] == 0:
                    print('Sorry there are no available doses of '+str(vaccine_name))
                    print('Please try again')
                    return
                else:
                    doses = row[0]

        except pymssql.Error:
            print("Error occurred when getting Vaccine")
            print('test1')
            cm.close_connection()

        # make sure they don't already have an appointment on same day
        existing_appointment = 'SELECT * FROM Schedule WHERE Time=%t AND PID=%p'
        existing_appointment = existing_appointment.replace('%t', "'"+str(d)[0:11]+"'")
        existing_appointment = existing_appointment.replace('%p', "'"+self.username+"'")
        try:
            cursor.execute(existing_appointment)
            result = cursor.fetchall()
            if len(result) != 0:
                print('You already have an appointment on '+str(d))
                print('Your appointmentID is '+str(result[0][0])+' with '+str(result[0][1]))
                return
        except pymssql.Error as e:
            print("Error occurred when getting appointment")
            print(e)
            cm.close_connection()

        # make reservation
        # make an appointment ID
        get_appointmentID = "SELECT AppointmentID FROM Schedule ORDER BY AppointmentID DESC"
        try:
            cursor.execute(get_appointmentID)
            result = cursor.fetchall()
            if len(result) == 0:
                appointmentID = 1
            else:
                #print(result[0][0])
                appointmentID = result[0][0] + 1
        except pymssql.Error as e:
            print('Error occurred while getting AppointmentID')
            cm.close_connection()


        # make the reservation
        make_reservation = "INSERT INTO Schedule (AppointmentID, CID, PID, Time, Vaccine)" \
                           "VALUES (AID_v, CID_v, PID_v, Time_v, Vaccine_v);"
        make_reservation = make_reservation.replace('AID_v', "'"+str(appointmentID)+"'")
        make_reservation = make_reservation.replace('CID_v', "'"+res_caregiver+"'")
        make_reservation = make_reservation.replace('PID_v', "'"+self.username+"'")
        make_reservation = make_reservation.replace('Time_v', "'"+str(d)+"'")
        make_reservation = make_reservation.replace('Vaccine_v', "'"+vaccine_name+"'")
        try:
            cursor.execute(make_reservation)
            print('Your appointment is scheduled for '+str(d)+' with '+str(res_caregiver))
            print('Your appointmentID is '+str(appointmentID))
            conn.commit()
        except pymssql.Error:
            print("Error occurred when getting Vaccine")
            cm.close_connection()


        # remove a vaccine dose, doses found when looking at vaccine availability
        vaccine = Vaccine(vaccine_name, doses).get()
        vaccine.decrease_available_doses(1)

        # delete caregiver availability for that day
        delete_availability = 'DELETE FROM Availabilities WHERE Username=%s AND Time=%t'
        delete_availability = delete_availability.replace('%s', "'"+res_caregiver+"'")
        delete_availability = delete_availability.replace('%t', "'"+str(d)+"'")
        try:
            cursor.execute(delete_availability)
            conn.commit()
        except pymssql.Error:
            print("Error occurred when updating caregiver availability")
            cm.close_connection()
        cm.close_connection()


    def show_appointments(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor()

        show_appointments = "SELECT AppointmentID, Vaccine, CID, Time FROM Schedule WHERE PID=%s"
        try:
            result = cursor.execute(show_appointments, self.username)
            if result is None:
                print("You have no appointments")
                return None
            for row in result:
                print('You are scheduled for ' + str(len(result)) + 'appointments')
                print('AppointmentID ' + str(row[0]) + ':' + str(row[1]) + 'vaccination on ' + str(row[3]) + 'with caregiver ' + str(row[2]))
                return
        except pymssql.Error as db_err:
            print("Error occurred when searching schedule")
