import sys
sys.path.append("../util/*")
sys.path.append("../db/*")
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql


class Appointment:
    def __init__(self, CID, PID, time, vaccine, caregiver_bool):
        self.CID = CID
        self.PID = PID
        self.time = time
        self.vaccine = vaccine
        self.caregiver_bool = caregiver_bool

    # getters
    def get(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor(as_dict=True)

        if caregiver_bool
        get_appointment_details = "SELECT Salt, Hash FROM Caregivers WHERE Username = %s"
