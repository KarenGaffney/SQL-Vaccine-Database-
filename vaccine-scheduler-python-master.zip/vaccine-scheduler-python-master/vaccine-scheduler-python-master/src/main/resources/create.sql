CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Patients (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time date,
    Username varchar(255) REFERENCES Caregivers,
    PRIMARY KEY (Time, Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Schedule (
    AppointmentID int,
    CID varchar(255),
    PID varchar(255),
    Time date,
    Vaccine varchar(255),
    PRIMARY KEY (AppointmentID),
    FOREIGN KEY (CID) REFERENCES Caregivers(Username),
    FOREIGN KEY (PID) REFERENCES Patients(Username)
);

